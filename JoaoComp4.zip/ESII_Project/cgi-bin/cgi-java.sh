#!/bin/bash
java -jar cgi-java.jar