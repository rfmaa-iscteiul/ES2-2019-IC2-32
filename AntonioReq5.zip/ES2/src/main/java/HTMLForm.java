import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Hashtable;

public class HTMLForm {

	public HTMLForm() throws FileNotFoundException, IOException{
		readForm();
	}
	
	
	public void readForm() throws FileNotFoundException, IOException {
		try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\agodi\\Documents\\wordpress\\form.html"))){
			
			String line;
			while((line = br.readLine()) != null) {
				System.out.println(line);
			}
			
		}
	}
	
	public static void main() throws FileNotFoundException, IOException{
		HTMLForm a = new HTMLForm();
	}
//	Hashtable form_data = cgi_lib.ReadParse(System.in);
	
}
