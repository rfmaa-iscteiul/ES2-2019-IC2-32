import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectLoader;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.PathFilter;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;



public class GitHubConnection {

	private Git g;
	private File f = new File("\\usr\\lib\\cgi-bin\\repositorio");
	private Repository r;
	private List<ObjectLoader> lista1 = new ArrayList<ObjectLoader>();
	private List<ObjectLoader> lista2 = new ArrayList<ObjectLoader>();
	private List<Ref> lista3 = new ArrayList<Ref>();
	
	
	
	public void funcao() throws InvalidRemoteException, TransportException, GitAPIException, IOException {
		
		if(f.isDirectory() && !f.exists()) {
			Git.cloneRepository()
            .setURI("https://github.com/vbasto-iscte/ESII1920.git")
            .setDirectory(new File("C:\\Users\\agodi\\Documents\\wordpress\\cgi-bin\\repositorio"))
            .call();
		}
		else {
			g =Git.open(new File("C:\\Users\\agodi\\Documents\\wordpress\\cgi-bin\\repositorio"));
        g.pull();
        g.checkout();
		}
		r=g.getRepository();
		lista3=g.tagList().call();
		for(Ref i: lista3) {
			ObjectId objectid = r.resolve(i.getName());
			RevWalk revwalk = new RevWalk(r);
			RevCommit revcommit = revwalk.parseCommit(objectid);
			RevTree revtree = revcommit.getTree();
			TreeWalk treewalk = new TreeWalk(r);
			treewalk.addTree(revtree);
			treewalk.setRecursive(true);
			treewalk.setFilter(PathFilter.create("covid19spreading.rdf"));
			if(!treewalk.next())
				throw new IllegalStateException("N�o encontrou ficheiro");
			ObjectId objectid2 = treewalk.getObjectId(0);
			ObjectLoader objloader = r.open(objectid2);
			lista1.add(objloader);
			int q =lista1.size()-1;

				lista2.add(lista1.get(q));
//				lista2.get(0).copyTo(System.out);
				
				PrintStream ficheiro = new PrintStream(new FileOutputStream("C:\\Users\\agodi\\Documents\\wordpress\\cgi-bin\\ficheirocovid19spreading.rdf"));
				lista2.get(0).copyTo(ficheiro);
				
		}
	}
	
	
	
	
	
	
	
	
	
	

	
	
	public GitHubConnection(){
		
	}

	
	

	
	
	
	
	
	
	
	
	public static void main(String[] args) throws IOException, ParserConfigurationException,  XPathExpressionException, InvalidRemoteException, TransportException, GitAPIException, SAXException {
		
		
		
		GitHubConnection b = new GitHubConnection();
		b.funcao();
	    System.out.println(cgi_lib.Header());
		HTMLForm a = new HTMLForm();


		   System.out.println(cgi_lib.HtmlBot());
		Hashtable form_data = cgi_lib.ReadParse(System.in);
	
		
		if(form_data.get("regiao").equals("Algarve"))
			System.out.println("Algarve tem ");
		
		File inputFile = new File("C:\\Users\\agodi\\Documents\\wordpress\\cgi-bin\\ficheirocovid19spreading.rdf");        	      	  
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize(); 
		 String query = "/RDF/NamedIndividual/@*";
         System.out.println("Query para obter a lista das regi�es: " + query);
         XPathFactory xpathFactory = XPathFactory.newInstance();
         XPath xpath = xpathFactory.newXPath();
         XPathExpression expr = xpath.compile(query);        
		
         
         //Regi�o Algarve
         
         if(form_data.get("regiao").equals("algarve")) {
        	 
        	 if(form_data.get("tipo").equals("testes")) {
         query = "//*[contains(@about,'Algarve')]/Testes/text()";  
         System.out.println("Query para obter o n�mero de testes feitos no Algarve: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
        	 }
         
        	 
        	 if(form_data.get("tipo").equals("infecoes")) {
         query = "//*[contains(@about,'Algarve')]/Infecoes/text()";
         System.out.println("Query para obter o n�mero de infe��es no Algarve: " + query);
         expr = xpath.compile(query);
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
        	 }
         
        	 if(form_data.get("tipo").equals("internamentos")) {
         query = "//*[contains(@about,'Algarve')]/Internamentos/text()";
         System.out.println("Query para obter o n�mero de internamentos no Algarve: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
        	 }
         }
         
         
         //Regi�o Alentejo
         if(form_data.get("regiao").equals("alentejo")) {
         
        	 
        	 
        	 if(form_data.get("tipo").equals("testes")) {
         query = "//*[contains(@about,'Alentejo')]/Testes/text()";  
         System.out.println("Query para obter o n�mero de testes feitos no Alentejo: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
        	 }
         
        	 
        	 
        	 if(form_data.get("tipo").equals("infecoes")) {
         query = "//*[contains(@about,'Alentejo')]/Infecoes/text()";
         System.out.println("Query para obter o n�mero de infe��es no Alentejo: " + query);
         expr = xpath.compile(query);
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
        	 }
         
         
       	 if(form_data.get("tipo").equals("internamentos")) {
         query = "//*[contains(@about,'Alentejo')]/Internamentos/text()";
         System.out.println("Query para obter o n�mero de internamentos no Alentejo: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
       	 }
         }
         
         //Regi�o Lisboa
         if(form_data.get("regiao").equals("lisboa")) {
        	 
        	 
         
        	 if(form_data.get("tipo").equals("testes")) {
         query = "//*[contains(@about,'Lisboa')]/Testes/text()";  
         System.out.println("Query para obter o n�mero de testes feitos no Lisboa: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
        	 }
         
         
         if(form_data.get("tipo").equals("infecoes")) {
         query = "//*[contains(@about,'Lisboa')]/Infecoes/text()";
         System.out.println("Query para obter o n�mero de infe��es no Lisboa: " + query);
         expr = xpath.compile(query);
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
         }
         
         
         if(form_data.get("tipo").equals("internamentos")) {
         query = "//*[contains(@about,'Lisboa')]/Internamentos/text()";
         System.out.println("Query para obter o n�mero de internamentos no Lisboa: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
         }
         }
        
         
         //Regi�o Norte
         if(form_data.get("regiao").equals("norte")) {
        	 
        	 
        	 
        	 
        	 if(form_data.get("tipo").equals("testes")) {
         query = "//*[contains(@about,'Norte')]/Testes/text()";  
         System.out.println("Query para obter o n�mero de testes feitos no Norte: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
        	 }
        
         
         if(form_data.get("tipo").equals("infecoes")) {
         query = "//*[contains(@about,'Norte')]/Infecoes/text()";
         System.out.println("Query para obter o n�mero de infe��es no Norte: " + query);
         expr = xpath.compile(query);
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
         }
         
         
         
         if(form_data.get("tipo").equals("internamentos")) {
         query = "//*[contains(@about,'Norte')]/Internamentos/text()";
         System.out.println("Query para obter o n�mero de internamentos no Norte: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
         }
         }
         
         
         //Regi�o Centro
         if(form_data.get("regiao").equals("centro")) {
         
        	 
        	 
        	 if(form_data.get("tipo").equals("testes")) {
         query = "//*[contains(@about,'Centro')]/Testes/text()";  
         System.out.println("Query para obter o n�mero de testes feitos no Centro: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
        	 }
         
         
         
         if(form_data.get("tipo").equals("infecoes")) {
         query = "//*[contains(@about,'Centro')]/Infecoes/text()";
         System.out.println("Query para obter o n�mero de infe��es no Centro: " + query);
         expr = xpath.compile(query);
         System.out.println(expr.evaluate(doc, XPathConstants.STRING));
         }
         
         
         if(form_data.get("tipo").equals("internamentos")) {
         query = "//*[contains(@about,'Centro')]/Internamentos/text()";
         System.out.println("Query para obter o n�mero de internamentos no Centro: " + query);
         expr = xpath.compile(query);     
         System.out.println(expr.evaluate(doc, XPathConstants.STRING)); 
         }
         }
         
         
         
         
	
	
}
}
