import static org.junit.Assert.*;

import java.io.IOException;

import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.junit.Test;

public class GitHubConnectionTest {

	@Test
	public void testFuncao() throws InvalidRemoteException, TransportException, GitAPIException, IOException {
		GitHubConnection u = new GitHubConnection();
		u.funcao();
	}

}
